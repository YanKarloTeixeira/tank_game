var objects;
(function (objects) {
    var Game = /** @class */ (function () {
        function Game() {
        }
        Game.playMusic = true;
        return Game;
    }());
    objects.Game = Game;
})(objects || (objects = {}));
//# sourceMappingURL=game.js.map