module config {
  export enum Scene {
    START,
    PLAY1,
    PLAY2,
    PLAY3,
    OVER
  }
}
